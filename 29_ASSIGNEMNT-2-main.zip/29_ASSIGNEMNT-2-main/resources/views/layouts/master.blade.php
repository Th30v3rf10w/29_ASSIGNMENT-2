<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" dir="{{ app()->getLocale() === 'ar' ? 'rtl' : 'ltr' }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'RegForm') }} - @yield('title')</title>
    <link rel="icon" href="{{ asset('favicon.ico') }}" type="image/x-icon">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- RTL support for Bootstrap -->
    @if(app()->getLocale() === 'ar')
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-rtl@5.3.0/dist/css/bootstrap-rtl.min.css" rel="stylesheet">
    @endif

    <style>
        :root {
            --text-direction: {{ app()->getLocale() === 'ar' ? 'rtl' : 'ltr' }};
            --text-align: {{ app()->getLocale() === 'ar' ? 'right' : 'left' }};
        }

        body {
            font-family: 'Figtree', sans-serif;
            background-color: #f8f9fa;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            direction: var(--text-direction);
            text-align: var(--text-align);
        }

        .form-container {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin-top: 20px;
            margin-bottom: 20px;
        }

        .required-field::after {
            content: '*';
            color: red;
            margin-left: 4px;
        }

        .content-wrapper {
            flex: 1;
        }

        .dropdown-menu {
            text-align: var(--text-align);
        }

        .dropdown-menu-end[dir="rtl"] {
            right: auto !important;
            left: 0 !important;
        }

        [dir="rtl"] .form-label {
            text-align: right;
        }

        [dir="rtl"] .input-group .btn {
            border-radius: 0.375rem 0 0 0.375rem;
        }

        [dir="rtl"] .input-group .form-control {
            border-radius: 0 0.375rem 0.375rem 0;
        }
    </style>

    @yield('styles')
</head>
<body>
    @include('partials.header')

    <div class="content-wrapper">
        <div class="container mt-4">
            @yield('content')
        </div>
    </div>

    @include('partials.footer')

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" defer></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" ></script>


    @yield('scripts')

</body>
</html>
