<?php
return [
    "copyright" => ". All rights reserved.",
    "title" => "User Registration System",
];
?>