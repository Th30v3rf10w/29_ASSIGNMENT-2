<?php

use App\Http\Controllers\LocaleController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RegistrationController;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/register', [RegistrationController::class, 'showForm'])->name('register.form');
Route::post('/register', [RegistrationController::class, 'submitForm'])->name('register.submit');
Route::get('/check-username', [RegistrationController::class, 'checkUsername']);

Route::post('/validate-whatsapp', [\App\Http\Controllers\WhatsAppValidationController::class, 'validateNumber']);

Route::get('locale/{lang}', [LocaleController::class, 'setLocale']) ->name('locale');

