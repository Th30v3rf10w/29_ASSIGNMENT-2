<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class WhatsAppValidationController extends Controller
{
    private function normalizeEgyptianWhatsAppNumber(string $number): ?string
    {
        $number = preg_replace('/\D/', '', $number);

        $allowedPrefixes = ['010', '011', '012', '015'];

        $prefixPattern = implode('|', $allowedPrefixes);
        $regex = "/^($prefixPattern)/";

        $length = strlen($number);

        if ($length === 12 && preg_match($regex, substr($number, 1))) {
            if ($number[0] === '2') {
                return $number;
            }
        }

        if ($length === 11 && preg_match($regex, $number)) {
            return "2$number";
        }

        return null;
    }

    public function validateWhatsAppNumber(string $number): array
    {
        $normalized = $this->normalizeEgyptianWhatsAppNumber($number);

        if ($normalized === null) {
            return [
                'valid' => false,
                'message' => __('register.whatsapp_invalid_format'),
                'normalized_number' => null,
            ];
        }
        /*
        Skipped it due to API limitations, you can uncomment it out if you want to use the API.
        */

        // $response = Http::withHeaders([
        //     'X-RapidAPI-Key' => env('RAPIDAPI_KEY'),
        //     'X-RapidAPI-Host' => 'whatsapp-number-validator3.p.rapidapi.com'
        // ])->post('https://whatsapp-number-validator3.p.rapidapi.com/WhatsappNumberHasItWithToken', [
        //     'phone_number' => $normalized
        // ]);

        // $responseData = $response->json();
        // $isValid = ($responseData['status'] ?? null) == 'valid';

        $isValid = true;

        return [
            'valid' => $isValid,
            'message' => $isValid ? __('register.whatsapp_valid') : __('register.whatsapp_invalid'),
            'normalized_number' => $normalized,
        ];
    }

    public function validateNumber(Request $request)
    {
        $request->validate([
            'whatsapp_number' => 'required|string'
        ]);

        $result = $this->validateWhatsAppNumber($request->whatsapp_number);
        
        return response()->json($result);
    }
}