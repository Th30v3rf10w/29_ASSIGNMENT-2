<?php 
return [
    "greeting" => "Welcome to User Registration System",
    "description" => "This application allows users to register with their personal information including
                WhatsApp validation and image upload.",
    "click" => "Click the button below to register a new account.",
    "proceed" => "Register Now",
]
?>