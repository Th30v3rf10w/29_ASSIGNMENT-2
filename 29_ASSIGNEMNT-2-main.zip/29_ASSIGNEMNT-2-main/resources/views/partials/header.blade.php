<header class="bg-dark text-white py-3 mb-4" style="display: block !important;">
    <div class="container">
        <div class="d-flex flex-wrap justify-content-between align-items-center">
            <div class="col-md-4 d-flex align-items-center">
                <a href="/" class="text-white text-decoration-none">
                    <h1 class="h4 mb-0">{{ config('app.name', 'Laravel') }}</h1>
                </a>
            </div>

            <ul class="nav col-md-4 justify-content-center list-unstyled d-flex">
                <li class="ms-3"><a class="text-white" href="/">@lang('register.home')</a></li>
                <li class="ms-3"><a class="text-white" href="{{ route('register.form') }}">@lang('register.title')</a></li>
            </ul>

            <div class="col-md-4 d-flex justify-content-end">
                <div class="dropdown">
                    <button class="btn btn-outline-light btn-sm dropdown-toggle" type="button" 
                            id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        @if(app()->getLocale() === 'ar')
                             العربية
                        @else
                             English
                        @endif
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                        <li>
                            <a class="dropdown-item d-flex justify-content-between align-items-center {{ app()->getLocale() === 'en' ? 'active' : '' }}" 
                               href="{{ route('locale', 'en') }}">
                                <span>English</span>
                                @if(app()->getLocale() === 'en')
                                    <i class="fas fa-check ms-2"></i>
                                @endif
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item d-flex justify-content-between align-items-center {{ app()->getLocale() === 'ar' ? 'active' : '' }}" 
                               href="{{ route('locale', 'ar') }}">
                                <span>العربية</span>
                                @if(app()->getLocale() === 'ar')
                                    <i class="fas fa-check ms-2"></i>
                                @endif
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</header>