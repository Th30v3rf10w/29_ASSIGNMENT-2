<footer class="bg-dark text-white py-3 mt-4">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <p class="mb-0">&copy; {{ date('Y') }} {{ config('app.name', 'Laravel') }}@lang('footer.copyright')</p>
            </div>
            <div class="col-md-6 text-md-end">
                <p class="mb-0">@lang('footer.title')</p>
            </div>
        </div>
    </div>
</footer>