<?php

return [
    // head
    'title' => 'التسجيل',
    'subtitle' => 'تسجيل مستخدم جديد',
    'home' => 'الرئيسية',

    // buttons
    'submit' => 'تسجيل',
    'check' => 'تفقُّد',
    'verify' => 'تحقُّق',
    'choose_image' => 'إرفاق ملف',
    'no file chosen' => 'لم يُختر أي ملف',

    // form
    'full_name' => 'الاسم الكامل',
    'username' => 'اسم المستخدم',
    'email' => 'البريد الإلكتروني',
    'phone' => 'رقم الهاتف',
    'password' => 'كلمة المرور',
    'confirm_password' => 'تأكيد كلمة المرور',
    'whatsapp_number' => 'رقم الواتساب',
    'address' => 'العنوان',
    'profile_image' => 'صورة الملف الشخصي',

    // validations
    'password_requirements' => 'ينبغي أن تحتوي كلمة المرور على ٨ أحرف على الأقل، ورقمٍ واحد، ورمزٍ خاص واحد.',
    'full_name_required' => 'يجب إدخال الاسم الكامل',
    'username_required' => 'يجب إدخال اسم المستخدم',
    'email_invalid' => 'يرجى إدخال بريد إلكتروني صالح',
    'phone_required' => 'يجب إدخال رقم الهاتف',
    'whatsapp_required' => 'يجب إدخال رقم الواتساب',
    'address_required' => 'يجب إدخال العنوان',
    'password_min_length' => 'ينبغي أن تتكون كلمة المرور من ٨ أحرف على الأقل',
    'password_needs_number' => 'ينبغي أن تحتوي كلمة المرور على رقم واحد على الأقل',
    'password_needs_special' => 'ينبغي أن تحتوي كلمة المرور على رمز خاص واحد على الأقل',
    'passwords_not_match' => 'كلمتا المرور غير متطابقتين',
    'image_required' => 'يُرجى اختيار صورة للملف الشخصي',

    // added validations
    'email_required' => 'يجب إدخال البريد الإلكتروني',
    'email_taken' => 'البريد الإلكتروني مستخدم بالفعل',
    'password_required' => 'يجب إدخال كلمة المرور',
    'image_invalid' => 'الملف المُرفَق يجب أن يكون صورة صالحة',
    'username_invalid' => 'اسم المستخدم غير صالح',

    // Username messages
    'username_available' => 'اسم المستخدم متاح',
    'username_taken' => 'اسم المستخدم مستخدم بالفعل',

    // WhatsApp messages
    'whatsapp_valid' => 'رقم الواتساب سليم',
    'whatsapp_invalid' => 'رقم الواتساب لا يصلح',
    'whatsapp_error' => 'وقعَ خلل أثناء التحقق من رقم الواتساب',
    'whatsapp_invalid_format' => 'الرقم غير صالح. يجب أن يبدأ الرقم ب 010/011/012/015 أو 12 رقم يبدأوا ب 2010/2011/2012/2015.',

    // General messages
    'registration_successful' => 'سُجِّلتَ بنجاح! شكرًا لانضمامك.',
    'form_errors' => 'يرجى تصحيح الأخطاء في النموذج.',
    'general_error' => 'وقعَ خلل. يُرجى المحاولة لاحقًا.',


];