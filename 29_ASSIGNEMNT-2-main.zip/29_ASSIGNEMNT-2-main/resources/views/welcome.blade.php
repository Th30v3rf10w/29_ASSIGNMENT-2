@extends('layouts.master')

@section('title', 'Welcome')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-8 text-center">
        <div class="form-container">
            <h1 class="display-4 mb-4">@lang('welcome.greeting')</h1>
            <p class="lead mb-4">@lang('welcome.description')</p>
            <hr class="my-4">
            <p>@lang('welcome.click')</p>
            <a href="{{ route('register.form') }}" class="btn btn-primary btn-lg">@lang('welcome.proceed')</a>
        </div>
    </div>
</div>
@endsection