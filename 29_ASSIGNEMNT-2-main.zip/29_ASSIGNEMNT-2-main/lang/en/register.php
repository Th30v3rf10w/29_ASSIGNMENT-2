<?php
return [

    // head
    'title' => 'Register',
    'subtitle' => 'User Registration',
    'home' => 'Home',
    // buttons
    'submit' => 'Register',
    'check' => 'Check',
    'verify' => 'Verify',
    'choose_image' => 'Choose Image',
    'no file chosen' => 'No file chosen',
    // form
    'full_name' => 'Full Name',
    'username' => 'Username',
    'email' => 'Email',
    'phone' => 'Phone Number',
    'password' => 'Password',
    'confirm_password' => 'Confirm Password',
    'whatsapp_number' => 'WhatsApp Number',
    'address' => 'Address',
    'profile_image' => 'Profile Image',
    //validtions
    'password_requirements' => 'Password must be at least 8 characters with at least 1 number and 1 special character.',
    'full_name_required' => 'Full name is required',
    'username_required' => 'Username is required',
    'email_invalid' => 'Please enter a valid email address',
    'phone_required' => 'Phone number is required',
    'whatsapp_required' => 'WhatsApp number is required',
    'address_required' => 'Address is required',
    'password_min_length' => 'Password must be at least 8 characters',
    'password_needs_number' => 'Password must contain at least 1 number',
    'password_needs_special' => 'Password must contain at least 1 special character',
    'passwords_not_match' => 'Passwords do not match',
    'image_required' => 'Please select an image',
    // added validations
    'email_required' => 'Email is required',
    'email_taken' => 'Email is already taken',
    'password_required' => 'Password is required',
    'image_invalid' => 'The uploaded file must be a valid image',
    'username_invalid' => 'Invalid username',
    // messages username
    'username_available' => 'Username is available',
    'username_taken' => 'Username is already taken',
    // messages WhatsApp
    'whatsapp_valid' => 'WhatsApp number is valid',
    'whatsapp_invalid' => 'Invalid WhatsApp number',
    'whatsapp_error' => 'Error validating WhatsApp number',
    // General messages
    'registration_successful' => 'Registration successful! Thank you for registering.',
    'form_errors' => 'Please correct the errors in the form.',
    'general_error' => 'An error occurred. Please try again later.',
    'whatsapp_invalid_format' => 'Invalid WhatsApp number format. Number must be 11 digits starting with 010/011/012/015 or 12 digits starting with 2010/2011/2012/2015.',

];



?>