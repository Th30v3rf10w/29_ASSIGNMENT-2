<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Mail\NewUserRegistered;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;

class RegistrationController extends Controller
{    
    protected $whatsAppValidator;
    public function __construct(WhatsAppValidationController $whatsAppValidator)
    {
        $this->whatsAppValidator = $whatsAppValidator;
    }

    public function showForm()
    {
        return view('pages.register');
    }

    public function submitForm(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'full_name' => 'required|string|max:255',
            'user_name' => 'required|string|max:255|unique:users,user_name',
            'phone' => 'required|string|max:20',
            'whatsapp_number' => 'required|string|max:20',
            'address' => 'required|string',
            'password' => ['required', 'confirmed', Password::min(8)->numbers()->symbols()],
            'email' => 'required|string|email|max:255|unique:users,email',
            'user_image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ], [
            'full_name.required' => __('register.full_name_required'),
            'user_name.required' => __('register.username_required'),
            'user_name.unique' => __('register.username_taken'),
            'email.required' => __('register.email_required'),
            'email.email' => __('register.email_invalid'),
            'email.unique' => __('register.email_taken'),
            'phone.required' => __('register.phone_required'),
            'whatsapp_number.required' => __('register.whatsapp_required'),
            'whatsapp_number.*' => __('register.whatsapp_invalid_format'),
            'address.required' => __('register.address_required'),
            'password.required' => __('register.password_required'),
            'password.confirmed' => __('register.passwords_not_match'),
            'password.min' => __('register.password_min_length'),
            'password.numbers' => __('register.password_needs_number'),
            'password.symbols' => __('register.password_needs_special'),
            'user_image.required' => __('register.image_required'),
            'user_image.image' => __('register.image_invalid'),
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        $whatsappValidation = $this->whatsAppValidator->validateWhatsAppNumber($request->whatsapp_number);
        if (!$whatsappValidation['valid']) {
            return redirect()->back()
                ->withErrors(['whatsapp_number' => __('register.whatsapp_invalid')])
                ->withInput();
        }
        
        
        $imageName = null; 
        if ($request->hasFile('user_image')) {
            $image = $request->file('user_image');
            $originalName = pathinfo($image->getClientOriginalName(), PATHINFO_FILENAME);
            $extension = $image->getClientOriginalExtension();
            $truncatedName = substr($originalName, 0, 50);
            $imageName = time() . '_' . $truncatedName . '.' . $extension;
            $image->storeAs('public/user_images', $imageName);
        }

        $user = User::create([
            'full_name' => $request->full_name,
            'user_name' => $request->user_name,
            'phone' => $request->phone,
            'whatsapp_number' => $whatsappValidation['normalized_number'] ?? $request->whatsapp_number,            'address' => $request->address,
            'password' => bcrypt($request->password),
            'email' => $request->email,
            'image_name' => $imageName,
        ]);

        Mail::to($user->email)->send(new NewUserRegistered($user->user_name));
        
        return redirect()->route('register.form')
            ->with('success', __('register.registration_successful'));
    }

    public function checkUsername(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'user_name' => 'required|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'valid' => false,
                'message' => __('register.username_invalid')
            ]);
        }

        $exists = User::where('user_name', strtolower($request->user_name))->exists();

        return response()->json([
            'valid' => !$exists,
            'message' => $exists ? __('register.username_taken') : __('register.username_available')
        ]);
    }
}