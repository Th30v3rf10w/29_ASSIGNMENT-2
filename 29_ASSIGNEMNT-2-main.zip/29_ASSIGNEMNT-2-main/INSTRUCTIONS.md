# User Registration System - Laravel Implementation

## Overview

This project implements a user registration system using Laravel. It includes a form with client-side and server-side validation, AJAX username checking, WhatsApp number validation, and image upload functionality.

## Features

-   User registration form with all required fields
-   Client-side validation for all form fields
-   Server-side validation with appropriate error messages
-   AJAX username availability checking
-   WhatsApp number validation (simulated API integration)
-   Image upload and storage
-   Responsive design with Bootstrap
-   Password strength requirements (min 8 chars, 1 number, 1 special character)

## Setup Instructions

### 1. Database Setup

The project is configured to use SQLite by default. The database file is already created at `database/database.sqlite`.

### 2. Run Migrations

To create the necessary database tables, run:

```
php artisan migrate
```

### 3. Start the Development Server

To start the Laravel development server, run:

```
php artisan serve
```

This will start the server at http://localhost:8000

### 4. Access the Registration Form

Visit http://localhost:8000/register to access the registration form.

## Testing the Application

1. **Form Validation**: Try submitting the form with invalid data to test both client-side and server-side validation.

2. **Username Checking**: Enter a username and click the "Check" button or tab out of the field to test the AJAX username availability check.

3. **WhatsApp Validation**: Enter a WhatsApp number and click the "Verify" button to test the WhatsApp validation (currently simulated).

4. **Image Upload**: Upload an image to test the file upload functionality.

5. **Form Submission**: Complete the form with valid data to test the full registration process.

## Security Features

-   CSRF protection on all forms
-   Password hashing using Laravel's built-in bcrypt implementation
-   Input sanitization and validation
-   Secure file upload handling

## Integration Notes for Team Members

### Adding New Features

This registration system is designed to be extensible. To add new features:

1. **Controllers**: Add new methods to existing controllers or create new controllers in `app/Http/Controllers`

2. **Routes**: Define new routes in `routes/web.php`

3. **Views**: Create new Blade templates in `resources/views` or modify existing ones

4. **Models**: Extend the User model or create new models in `app/Models`

### API Integration

To implement the real WhatsApp validation API:

1. Get an API key from RapidAPI for the WhatsApp Number Validator
2. Update the JavaScript code in `resources/views/pages/register.blade.php` to use the actual API
3. Store the API key securely in the `.env` file

## File Structure

-   **Migration**: `database/migrations/2023_05_15_000000_create_users_table.php`
-   **Model**: `app/Models/User.php`
-   **Controller**: `app/Http/Controllers/RegistrationController.php`
-   **Routes**: `routes/web.php`
-   **Views**:
    -   `resources/views/layouts/master.blade.php`
    -   `resources/views/partials/header.blade.php`
    -   `resources/views/partials/footer.blade.php`
    -   `resources/views/pages/register.blade.php`
