<?php
namespace Tests\Feature;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class RegistrationTest extends TestCase
{
    use RefreshDatabase;
    use WithFaker;

    protected function setUp(): void
    {
        parent::setUp();
        Storage::fake('public');
    }

    public function test_register_page_returns_200()
    {
        $response = $this->get('/register');
        $response->assertStatus(200);
    }

    public function test_valid_registration_inserts_into_db()
    {
        $userData = [
            'full_name' => 'Test User',
            'user_name' => 'testuser',
            'email' => 'test@example.com',
            'password' => 'Password123!',
            'password_confirmation' => 'Password123!',
            'phone' => '1234567890',
            'whatsapp_number' => '+1234567890',
            'address' => '123 Test St',
            'user_image' => UploadedFile::fake()->image('avatar.jpg')
        ];

        $response = $this->postJson('/register', $userData);

        $response->assertStatus(201)
            ->assertJson([
                'success' => true,
                'message' => 'Registration successful!'
            ]);

        $this->assertDatabaseHas('users', [
            'user_name' => 'testuser',
            'email' => 'test@example.com'
        ]);

        Storage::disk('public')->assertExists('user_images/' . User::first()->image_name);
    }

    public function test_duplicate_username_fails()
    {
        // First create a user
        User::create([
            'full_name' => 'Existing User',
            'user_name' => 'existinguser',
            'email' => 'existing@example.com',
            'password' => bcrypt('Password123!'),
            'phone' => '1234567890',
            'whatsapp_number' => '+1234567890',
            'address' => '123 Existing St',
            'image_name' => 'existing.jpg'
        ]);

        $userData = [
            'full_name' => 'Test User',
            'user_name' => 'existinguser', // Duplicate username
            'email' => 'new@example.com',
            'password' => 'Password123!',
            'password_confirmation' => 'Password123!',
            'phone' => '0987654321',
            'whatsapp_number' => '+0987654321',
            'address' => '456 Test St',
            'user_image' => UploadedFile::fake()->image('avatar.jpg')
        ];

        $response = $this->postJson('/register', $userData);

        $response->assertStatus(422)
            ->assertJsonStructure([
                'success',
                'errors' => ['user_name']
            ]);
    }

    public function test_invalid_email_format_fails()
    {
        $userData = [
            'full_name' => 'Test User',
            'user_name' => 'testuser',
            'email' => 'invalid-email', // Invalid email format
            'password' => 'Password123!',
            'password_confirmation' => 'Password123!',
            'phone' => '1234567890',
            'whatsapp_number' => '+1234567890',
            'address' => '123 Test St',
            'user_image' => UploadedFile::fake()->image('avatar.jpg')
        ];

        $response = $this->postJson('/register', $userData);

        $response->assertStatus(422)
            ->assertJsonStructure([
                'success',
                'errors' => ['email']
            ]);
    }

    public function test_password_requires_numbers_and_symbols()
    {
        $userData = [
            'full_name' => 'Test User',
            'user_name' => 'testuser',
            'email' => 'test@example.com',
            'password' => 'Passwordonly', // Missing numbers and symbols
            'password_confirmation' => 'Passwordonly',
            'phone' => '1234567890',
            'whatsapp_number' => '+1234567890',
            'address' => '123 Test St',
            'user_image' => UploadedFile::fake()->image('avatar.jpg')
        ];

        $response = $this->postJson('/register', $userData);

        $response->assertStatus(422)
            ->assertJsonStructure([
                'success',
                'errors' => ['password']
            ]);
    }

// Add these new test methods to your RegistrationTest class

public function test_password_must_contain_number_and_symbol()
{
    $userData = [
        'full_name' => 'Test User',
        'user_name' => 'testuser',
        'email' => 'test@example.com',
        'password' => 'Passwordonly', // Missing number and symbol
        'password_confirmation' => 'Passwordonly',
        'phone' => '1234567890',
        'whatsapp_number' => '+1234567890',
        'address' => '123 Test St',
        'user_image' => UploadedFile::fake()->image('avatar.jpg')
    ];

    $response = $this->postJson('/register', $userData);

    $response->assertStatus(422)
        ->assertJsonStructure([
            'success',
            'errors' => ['password']
        ]);
}

public function test_password_minimum_length()
{
    $userData = [
        'full_name' => 'Test User',
        'user_name' => 'testuser',
        'email' => 'test@example.com',
        'password' => 'Pw1!', // Less than 8 characters
        'password_confirmation' => 'Pw1!',
        'phone' => '1234567890',
        'whatsapp_number' => '+1234567890',
        'address' => '123 Test St',
        'user_image' => UploadedFile::fake()->image('avatar.jpg')
    ];

    $response = $this->postJson('/register', $userData);

    $response->assertStatus(422)
        ->assertJsonStructure([
            'success',
            'errors' => ['password']
        ]);
}

public function test_maximum_length_validations()
{
    $tooLongString = str_repeat('a', 256); // 256 characters

    $userData = [
        'full_name' => $tooLongString,
        'user_name' => $tooLongString,
        'email' => $tooLongString . '@example.com',
        'password' => 'Password123!',
        'password_confirmation' => 'Password123!',
        'phone' => '1234567890',
        'whatsapp_number' => '+1234567890',
        'address' => '123 Test St',
        'user_image' => UploadedFile::fake()->image('avatar.jpg')
    ];

    $response = $this->postJson('/register', $userData);

    $response->assertStatus(422)
        ->assertJsonStructure([
            'success',
            'errors' => ['full_name', 'user_name', 'email']
        ]);
}

public function test_required_fields()
{
    $response = $this->postJson('/register', []);

    $response->assertStatus(422)
        ->assertJsonStructure([
            'success',
            'errors' => [
                'full_name',
                'user_name',
                'email',
                'password',
                'phone',
                'whatsapp_number',
                'address',
                'user_image'
            ]
        ]);
}

public function test_invalid_image_type()
{
    $userData = [
        'full_name' => 'Test User',
        'user_name' => 'testuser',
        'email' => 'test@example.com',
        'password' => 'Password123!',
        'password_confirmation' => 'Password123!',
        'phone' => '1234567890',
        'whatsapp_number' => '+1234567890',
        'address' => '123 Test St',
        'user_image' => UploadedFile::fake()->create('document.pdf', 100) // Invalid mime type
    ];

    $response = $this->postJson('/register', $userData);

    $response->assertStatus(422)
        ->assertJsonStructure([
            'success',
            'errors' => ['user_image']
        ]);
}

public function test_image_too_large()
{
    $userData = [
        'full_name' => 'Test User',
        'user_name' => 'testuser',
        'email' => 'test@example.com',
        'password' => 'Password123!',
        'password_confirmation' => 'Password123!',
        'phone' => '1234567890',
        'whatsapp_number' => '+1234567890',
        'address' => '123 Test St',
        'user_image' => UploadedFile::fake()->create('avatar.jpg', 3000) // Larger than 2048KB
    ];

    $response = $this->postJson('/register', $userData);

    $response->assertStatus(422)
        ->assertJsonStructure([
            'success',
            'errors' => ['user_image']
        ]);
}

    protected function tearDown(): void
    {
        Storage::disk('public')->deleteDirectory('user_images');
        parent::tearDown();
    }
}
