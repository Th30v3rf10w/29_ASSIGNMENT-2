@extends('layouts.master')

@section('title', __('register.title'))

@section('content')
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="form-container">
            <h2 class="text-center mb-4">@lang('register.subtitle')</h2>

            <div id="alert-container"></div>

            <form id="registrationForm" novalidate method="POST" action="{{ route('register.submit') }}"
                enctype="multipart/form-data">
                @csrf

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="full_name" class="form-label required-field">@lang('register.full_name')</label>
                        <input type="text" class="form-control" id="full_name" name="full_name" value="{{ old('full_name') }}" required>
                        <div class="invalid-feedback" id="full_name-error"></div>
                    </div>

                    <div class="col-md-6">
                        <label for="user_name" class="form-label required-field">@lang('register.username')</label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="user_name" name="user_name" value="{{ old('user_name') }}" required>
                            <button class="btn btn-outline-secondary" type="button"
                                id="check-username">@lang('register.check')</button>
                        </div>
                        <div class="invalid-feedback" id="user_name-error"></div>
                        <small id="username-status" class="form-text"></small>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="email" class="form-label required-field">@lang('register.email')</label>
                        <input type="email" class="form-control" id="email" name="email" value="{{ old('email') }}" required>
                        <div class="invalid-feedback" id="email-error"></div>
                    </div>

                    <div class="col-md-6">
                        <label for="phone" class="form-label required-field">@lang('register.phone')</label>
                        <input type="text" class="form-control" id="phone" name="phone" value="{{ old('phone') }}" required>
                        <div class="invalid-feedback" id="phone-error"></div>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="whatsapp_number"
                            class="form-label required-field">@lang('register.whatsapp_number')</label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="whatsapp_number" name="whatsapp_number"
                                value="{{ old('whatsapp_number') }}" required>
                            <button class="btn btn-outline-secondary" type="button"
                                id="verify-whatsapp">@lang('register.verify')</button>
                        </div>
                        <div class="invalid-feedback" id="whatsapp_number-error"></div>
                        <small id="whatsapp-status" class="form-text"></small>
                    </div>

                    <div class="col-md-6">
                        <label for="address" class="form-label required-field">@lang('register.address')</label>
                        <textarea class="form-control" id="address" name="address" rows="2" required>{{ old('address') }}</textarea>
                        <div class="invalid-feedback" id="address-error"></div>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="password" class="form-label required-field">@lang('register.password')</label>
                        <input type="password" class="form-control" id="password" name="password" value = "{{ old('password') }}" required>
                        <div class="invalid-feedback" id="password-error"></div>
                        <small class="form-text text-muted">@lang('register.password_requirements')</small>
                    </div>

                    <div class="col-md-6">
                        <label for="password_confirmation"
                            class="form-label required-field">@lang('register.confirm_password')</label>
                        <input type="password" class="form-control" id="password_confirmation"
                            name="password_confirmation" required>
                        <div class="invalid-feedback" id="password_confirmation-error"></div>
                    </div>
                </div>
                {{-- file input styling to overwrite default behavior that i cant translate --}}
                <style>
                .file-input {
                    display: none;
                }

                .custom-file-label {
                    display: inline-block;
                    padding: 0.5rem 1rem;
                    background-color: #eee;
                    border: 1px solid #ccc;
                    cursor: pointer;
                }

                .file-name {
                    margin-left: 1rem;
                }
                </style>

                <div class="mb-3">
                    <label for="customFileInput" class="custom-file-label" id="fileLabel" style="cursor:pointer;">
                        @lang('register.choose_image')
                    </label>
                    <input type="file" id="customFileInput" name="user_image" class="file-input" value = "{{ old('user_image') }}" required />
                    <span class="file-name" id="fileName">@lang('register.no file chosen')</span>
                    <div class="invalid-feedback" id="user_image-error"></div>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">@lang('register.submit')</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
let whatsappVerified = false;
const translations = {
    full_name_required: "{{ __('register.full_name_required') }}",
    username_required: "{{ __('register.username_required') }}",
    email_required: "{{ __('register.email_required') }}",
    email_invalid: "{{ __('register.email_invalid') }}",
    phone_required: "{{ __('register.phone_required') }}",
    whatsapp_required: "{{ __('register.whatsapp_required') }}",
    address_required: "{{ __('register.address_required') }}",
    password_min_length: "{{ __('register.password_min_length') }}",
    password_needs_number: "{{ __('register.password_needs_number') }}",
    password_needs_special: "{{ __('register.password_needs_special') }}",
    passwords_not_match: "{{ __('register.passwords_not_match') }}",
    image_required: "{{ __('register.image_required') }}",
    username_available: "{{ __('register.username_available') }}",
    username_taken: "{{ __('register.username_taken') }}",
    whatsapp_valid: "{{ __('register.whatsapp_valid') }}",
    whatsapp_invalid: "{{ __('register.whatsapp_invalid') }}",
    whatsapp_error: "{{ __('register.whatsapp_error') }}",
    registration_successful: "{{ __('register.registration_successful') }}",
    form_errors: "{{ __('register.form_errors') }}",
    general_error: "{{ __('register.general_error') }}",
    'no file chosen': "{{ __('register.no file chosen') }}"
};
const successMessage = "{{ session('success') }}";
const errorMessage = "{{ $errors->first() }}";
$(document).ready(function() {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    const alertContainer = $('#alert-container');

    if (successMessage) {
        alertContainer.html(
            '<div class="alert alert-success alert-dismissible fade show" role="alert">' +
            successMessage +
            '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
            '</div>'
        );
    }

    if (errorMessage) {
        alertContainer.html(
            '<div class="alert alert-danger alert-dismissible fade show" role="alert">' +
            errorMessage +
            '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
            '</div>'
        );
    }

    $('#customFileInput').on('change', function() {
        const fileName = this.files.length > 0 ? this.files[0].name : translations['no file chosen'];
        $('#fileName').text(fileName);
    });

    $('#check-username').on('click', function() {
        checkUsername();
    });

    $('#user_name').on('blur', function() {
        checkUsername();
    });

    function checkUsername() {
        const username = $('#user_name').val().trim();
        if (username.length > 0) {
            $('#username-status').html('<span class="text-info">Checking...</span>');

            $.ajax({
                url: '/check-username',
                type: 'GET',
                data: {
                    user_name: username
                },
                success: function(response) {
                    if (response.valid) {
                        $('#username-status').html(
                            '<span class="text-success">' + response.message + '</span>');
                        $('#user_name').removeClass('is-invalid').addClass('is-valid');
                    } else {
                        $('#username-status').html(
                            '<span class="text-danger">' + response.message + '</span>'
                        );
                        $('#user_name').removeClass('is-valid').addClass('is-invalid');
                    }
                },
                error: function() {
                    $('#username-status').html(
                        '<span class="text-danger">Error checking username</span>');
                }
            });
        }
    }

    $('#verify-whatsapp').click(function() {
        const whatsappNumber = $('#whatsapp_number').val().trim();
        if (whatsappNumber.length > 0) {
            $('#whatsapp-status').html('<span class="text-info">Verifying...</span>');

            $.ajax({
                url: '/validate-whatsapp',
                type: 'POST',
                data: {
                    whatsapp_number: whatsappNumber
                },
                success: function(response) {
                    if (response.valid) {
                        whatsappVerified = true;
                        $('#whatsapp-status').html(
                            '<span class="text-success">' + response.message + '</span>'
                        );
                        $('#whatsapp_number').removeClass('is-invalid').addClass(
                            'is-valid');
                    } else {
                        whatsappVerified = false;
                        $('#whatsapp-status').html(
                            '<span class="text-danger">' + response.message + '</span>');
                        $('#whatsapp_number').removeClass('is-valid').addClass(
                            'is-invalid');
                    }
                },
                error: function() {
                    whatsappVerified = false;
                    $('#whatsapp-status').html('<span class="text-danger">' + translations
                        .whatsapp_error + '</span>');
                    $('#whatsapp_number').removeClass('is-valid').addClass('is-invalid');
                }
            });
        }
    });

    $('#whatsapp_number').on('input', function() {
        whatsappVerified = false;
        $('#whatsapp_number').removeClass('is-valid is-invalid');
        $('#whatsapp-status').empty();
    });
});
</script>
@endsection